const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

import {
  createGameState, performAttack, playBasicToBench, setActivePokemon,
  attachEnergy, evolvePokemon, retreat, playTrainer, endTurn,
  performAITurn
} from "@/lib/gameEngine";
import { buildRandomAIDeck } from "@/lib/pokemonTCGApi";
import { syncGameState, subscribeToRoom, recordMatchResult } from "@/lib/multiplayerSync";
import BattleField from "@/components/battle/BattleField";
import PlayerHand from "@/components/battle/PlayerHand";
import BattleLog from "@/components/battle/BattleLog";
import SetupPhase from "@/components/battle/SetupPhase";
import GameOverScreen from "@/components/battle/GameOverScreen";
import { Loader2 } from "lucide-react";
import { SAMPLE_CARDS } from "@/lib/cardData";

function makeSampleDeckDefs() {
  return SAMPLE_CARDS.filter(c => c.card_type === "pokemon" || c.card_type === "energy")
    .slice(0, 30)
    .map(c => ({
      id: c.name,
      name: c.name,
      supertype: c.card_type === "pokemon" ? "Pokémon" : "Energy",
      subtypes: c.stage ? [c.stage === "basic" ? "Basic" : c.stage === "stage1" ? "Stage 1" : "Stage 2"] : ["Basic"],
      hp: c.hp || null,
      types: c.energy_type ? [c.energy_type.charAt(0).toUpperCase() + c.energy_type.slice(1)] : [],
      evolvesFrom: null,
      attacks: c.attack1_name ? [{
        name: c.attack1_name,
        cost: Array(c.attack1_cost || 1).fill("Colorless"),
        convertedEnergyCost: c.attack1_cost || 1,
        damage: `${c.attack1_damage || 0}`,
        damageValue: c.attack1_damage || 0,
        text: "",
      }, ...(c.attack2_name ? [{
        name: c.attack2_name,
        cost: Array(c.attack2_cost || 2).fill("Colorless"),
        convertedEnergyCost: c.attack2_cost || 2,
        damage: `${c.attack2_damage || 0}`,
        damageValue: c.attack2_damage || 0,
        text: "",
      }] : [])] : [],
      abilities: [],
      weaknesses: c.weakness ? [{ type: c.weakness.charAt(0).toUpperCase() + c.weakness.slice(1), value: "×2" }] : [],
      resistances: [],
      retreatCost: Array(c.retreat_cost || 1).fill("Colorless"),
      convertedRetreatCost: c.retreat_cost || 1,
      rules: [],
      rarity: c.rarity,
      imageSmall: null,
      imageLarge: null,
      isBasicEnergy: c.card_type === "energy",
      isSupporter: false,
      isItem: false,
      isStadium: false,
      isTool: false,
      stage: c.stage || "basic",
    }));
}

export default function Battle() {
  const urlParams = new URLSearchParams(window.location.search);
  const roomId = urlParams.get("room");
  const playerSide = urlParams.get("player") || "player1";
  const isAI = urlParams.get("ai") === "true";
  const mode = urlParams.get("mode") || "unlimited";
  const navigate = useNavigate();

  const [gs, setGs] = useState(null);
  const [loading, setLoading] = useState(true);
  const [phase, setPhase] = useState("loading"); // loading | setup | playing | finished
  const [selectedCard, setSelectedCard] = useState(null);
  const [actionMode, setActionMode] = useState(null); // "attack" | "energy" | "evolve" | "retreat"
  const [logOpen, setLogOpen] = useState(false);
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const unsubRef = useRef(null);
  const startTimeRef = useRef(Date.now());
  const [user, setUser] = useState(null);

  useEffect(() => {
    db.auth.me().then(setUser).catch(() => {});
  }, []);