import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import BottomNav from "@/components/tcg/BottomNav";
import PageHeader from "@/components/tcg/PageHeader";
import { tcgdex, getTypeInfo } from "@/lib/tcgdex";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Search } from "lucide-react";

export default function Collection() {
  const [sets, setSets] = useState([]);
  const [selectedSet, setSelectedSet] = useState(null);
  const [setCards, setSetCards] = useState([]);
  const [selectedCard, setSelectedCard] = useState(null);
  const [cardDetail, setCardDetail] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    tcgdex.getSets().then(setSets).catch(() => {});
  }, []);

  const loadSet = async (set) => {
    setSelectedSet(set);
    setLoading(true);
    const cards = await tcgdex.getSetCards(set.id).catch(() => []);
    setSetCards(cards);
    setLoading(false);
  };

  const viewCard = async (card) => {
    setSelectedCard(card);
    const detail = await tcgdex.getCard(card.id).catch(() => null);
    setCardDetail(detail || card);
  };

  const filtered = setCards.filter((c) =>
    !search || c.name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-8">
        <PageHeader
          title="CARD DATABASE"
          subtitle="All sets via TCGdex"
          backLink={selectedSet ? null : "/"}
          rightAction={selectedSet && (
            <button onClick={() => { setSelectedSet(null); setSetCards([]); setSearch(""); }}
              className="text-accent text-sm font-body">← Sets</button>
          )}
        />

        {!selectedSet ? (
          // Set browser
          <div className="grid grid-cols-2 gap-3">
            {sets.map((set) => (
              <motion.button
                key={set.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onClick={() => loadSet(set)}
                className="bg-card border border-border rounded-xl p-4 text-left hover:bg-secondary transition-colors"
              >
                {set.logo && <img src={`${set.logo}/logo.png`} alt={set.name} className="h-8 object-contain mb-2" onError={(e) => e.target.style.display = "none"} />}
                <p className="font-body font-semibold text-sm">{set.name}</p>
                <p className="font-body text-xs text-muted-foreground">{set.cardCount?.total || "?"} cards</p>
              </motion.button>
            ))}
          </div>
        ) : (
          <>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Search cards..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 bg-secondary border-border font-body" />
            </div>

            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {filtered.map((card) => (
                  <TcgCard key={card.id} card={card} onClick={() => viewCard(card)} />
                ))}
              </div>
            )}