const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { tcgdex, getTypeInfo } from "@/lib/tcgdex";
import PageHeader from "@/components/tcg/PageHeader";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Trash2, Loader2, Search, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

export default function DeckBuilder() {
  const urlParams = new URLSearchParams(window.location.search);
  const deckId = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [deckName, setDeckName] = useState("New Deck");
  const [mode, setMode] = useState("unlimited");
  const [deckCardIds, setDeckCardIds] = useState([]); // TCGdex card IDs
  const [deckCards, setDeckCards] = useState([]); // loaded card objects

  const [sets, setSets] = useState([]);
  const [selectedSet, setSelectedSet] = useState(null);
  const [setCards, setSetCards] = useState([]);
  const [search, setSearch] = useState("");
  const [loadingSet, setLoadingSet] = useState(false);

  useEffect(() => { tcgdex.getSets().then(setSets).catch(() => {}); }, []);

  // Load existing deck
  useEffect(() => {
    if (!deckId) return;
    db.entities.Deck.filter({ id: deckId }).then(async (decks) => {
      const d = decks[0];
      if (!d) return;
      setDeckName(d.name);
      setMode(d.mode);
      const ids = d.card_ids || [];
      setDeckCardIds(ids);
      const loaded = await Promise.allSettled(ids.map((id) => tcgdex.getCard(id)));
      setDeckCards(loaded.filter((r) => r.status === "fulfilled").map((r) => r.value));
    });
  }, [deckId]);

  const loadSet = async (set) => {
    setSelectedSet(set);
    setLoadingSet(true);
    const cards = await tcgdex.getSetCards(set.id).catch(() => []);
    setSetCards(cards);
    setLoadingSet(false);
  };

  const addCard = async (card) => {
    const count = deckCardIds.filter((id) => id === card.id).length;
    if (count >= 4) { toast({ title: "Max 4 copies per card" }); return; }
    if (deckCardIds.length >= 60) { toast({ title: "Deck is full (60 cards)" }); return; }
    setDeckCardIds((prev) => [...prev, card.id]);
    // Load full card if needed
    if (!deckCards.find((c) => c.id === card.id)) {
      const full = await tcgdex.getCard(card.id).catch(() => card);
      setDeckCards((prev) => [...prev, full]);
    }
  };

  const removeCard = (id) => {
    const idx = deckCardIds.lastIndexOf(id);
    if (idx !== -1) {
      setDeckCardIds((prev) => { const a = [...prev]; a.splice(idx, 1); return a; });
    }
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const coverCard = deckCards[0];
      const data = {
        name: deckName, mode,
        card_ids: deckCardIds,
        card_count: deckCardIds.length,
        cover_card_id: coverCard?.id || null,
        cover_image_url: coverCard?.image ? `${coverCard.image}/low.webp` : null,
      };
      return deckId ? db.entities.Deck.update(deckId, data) : db.entities.Deck.create(data);