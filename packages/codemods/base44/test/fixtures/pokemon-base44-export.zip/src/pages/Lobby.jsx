const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import BottomNav from "@/components/tcg/BottomNav";
import PageHeader from "@/components/tcg/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { createRoom, joinRoom } from "@/lib/multiplayerSync";
import { Swords, Trophy, Users, Loader2, Crown, Shield, Star } from "lucide-react";

const TIER_STYLES = {
  bronze:   { color: "text-orange-400",  bg: "bg-orange-400/10",  icon: "🥉" },
  silver:   { color: "text-slate-300",   bg: "bg-slate-300/10",   icon: "🥈" },
  gold:     { color: "text-yellow-400",  bg: "bg-yellow-400/10",  icon: "🥇" },
  platinum: { color: "text-cyan-300",    bg: "bg-cyan-300/10",    icon: "💎" },
  diamond:  { color: "text-blue-400",    bg: "bg-blue-400/10",    icon: "💠" },
  master:   { color: "text-purple-400",  bg: "bg-purple-400/10",  icon: "👑" },
};

export default function Lobby() {
  const navigate = useNavigate();
  const [tab, setTab] = useState("play"); // play | ranked | leaderboard
  const [mode, setMode] = useState("unlimited");
  const [roomCode, setRoomCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    db.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: myRank } = useQuery({
    queryKey: ["my-rank", user?.id],
    queryFn: () => db.entities.PlayerRank.filter({ user_id: user?.id }),
    enabled: !!user?.id,
    select: d => d?.[0],
  });

  const { data: leaderboard = [] } = useQuery({
    queryKey: ["leaderboard"],
    queryFn: () => db.entities.PlayerRank.list("-elo", 20),
    enabled: tab === "leaderboard",
  });

  const { data: openRooms = [] } = useQuery({
    queryKey: ["open-rooms"],
    queryFn: () => db.entities.GameRoom.filter({ status: "waiting" }),
    enabled: tab === "play",
    refetchInterval: 5000,
  });

  const handleCreate = async () => {
    setLoading(true); setError("");
    const deck = []; // TODO: load selected deck cards
    const room = await createRoom(user?.full_name || "Player", mode, deck);
    navigate(`/battle?room=${room.id}&player=player1&mode=${mode}`);
  };

  const handleJoin = async () => {
    if (!roomCode.trim()) return;
    setLoading(true); setError("");
    const deck = [];
    const room = await joinRoom(roomCode.trim().toUpperCase(), user?.full_name || "Player", deck);
    navigate(`/battle?room=${room.id}&player=player2&mode=${room.mode}`);
  };

  const handleJoinRoom = async (room) => {
    setLoading(true);
    const deck = [];
    const updated = await joinRoom(room.code, user?.full_name || "Player", deck);
    navigate(`/battle?room=${updated.id}&player=player2&mode=${room.mode}`);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-8">
        <PageHeader title="PLAY" subtitle="Find a match or challenge a friend" />

        {/* My Rank Card */}
        {myRank && (
          <div className={`mb-6 rounded-2xl border border-border p-4 flex items-center gap-4 ${TIER_STYLES[myRank.rank_tier]?.bg}`}>
            <span className="text-3xl">{TIER_STYLES[myRank.rank_tier]?.icon}</span>